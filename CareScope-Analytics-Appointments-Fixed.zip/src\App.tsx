import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Activity, Ambulance, ArrowDownRight, ArrowUpRight, BedDouble, Bell, Building2, CalendarDays,
  Check, ChevronDown, CircleDot, ClipboardCheck, Clock3, Download, Droplets, FileBarChart2,
  Gauge, HeartPulse, LayoutDashboard, Menu, Moon, MoreHorizontal, Search, Settings, Stethoscope,
  Sun, TrendingUp, Users, WalletCards, X, Zap, Plus, UserPlus, FilePlus2, Palette, type LucideIcon,
} from "lucide-react";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Legend, Line, LineChart,
  Pie, PieChart, RadialBar, RadialBarChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { Link, Navigate, Route, Routes, useLocation, useNavigate } from "react-router-dom";
import { appointments, bedForecast, diseases, doctors, forecast, patients, reports, revenue, timeline, visits } from "./data";

type Theme = "light" | "dark";
type Accent = "blue" | "emerald" | "purple";
const ThemeContext = createContext<{ theme: Theme; accent: Accent; toggle: () => void; setAccent: (accent: Accent) => void }>({ theme: "light", accent: "blue", toggle: () => undefined, setAccent: () => undefined });
const useTheme = () => useContext(ThemeContext);
const fmt = new Intl.NumberFormat("en-US");
const anim = { initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, transition: { duration: 0.35 } };

function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>("light");
  const [accent, setAccent] = useState<Accent>("blue");
  useEffect(() => { document.documentElement.classList.toggle("dark", theme === "dark"); }, [theme]);
  useEffect(() => { document.documentElement.dataset.accent = accent; }, [accent]);
  return <ThemeContext.Provider value={{ theme, accent, toggle: () => setTheme(v => v === "light" ? "dark" : "light"), setAccent }}>{children}</ThemeContext.Provider>;
}

const nav = [
  { label: "Dashboard", to: "/dashboard", icon: LayoutDashboard },
  { label: "Appointments", to: "/appointments", icon: CalendarDays },
  { label: "Patients", to: "/patients", icon: Users },
  { label: "Reports", to: "/reports", icon: FileBarChart2 },
  { label: "Resources", to: "/resources", icon: BedDouble },
  { label: "Settings", to: "/settings", icon: Settings },
];

function Logo({ compact = false }: { compact?: boolean }) {
  return <div className="logo"><span className="logoMark"><HeartPulse size={20} /></span>{!compact && <span>CareScope<small>Analytics</small></span>}</div>;
}

function Sidebar({ open, close }: { open: boolean; close: () => void }) {
  const { pathname } = useLocation();
  return <>
    <AnimatePresence>{open && <motion.button aria-label="Close menu" className="scrim" onClick={close} initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />}</AnimatePresence>
    <aside className={`sidebar ${open ? "open" : ""}`}>
      <div className="sideHead"><Logo /><button className="iconBtn mobileOnly" onClick={close}><X size={20} /></button></div>
      <nav className="sideNav">{nav.map(({ label, to, icon: Icon }) =>
        <Link key={to} to={to} onClick={close} className={pathname === to ? "active" : ""}><Icon size={19} /><span>{label}</span>{label === "Appointments" && <b>12</b>}</Link>
      )}</nav>
      <div className="sideBottom">
        <div className="upgrade"><span><Zap size={15} /></span><strong>Command center</strong><p>All systems operational</p><div><i />99.98% uptime</div></div>
        <div className="support"><span className="avatar">SM</span><div><strong>Sarah Mitchell</strong><small>Chief Medical Officer</small></div><MoreHorizontal size={18} /></div>
      </div>
    </aside>
  </>;
}

function Header({ menu }: { menu: () => void }) {
  const [clock, setClock] = useState(new Date());
  const [profile, setProfile] = useState(false);
  const [notice, setNotice] = useState(false);
  const [query, setQuery] = useState("");
  const { theme, toggle } = useTheme();
  const navigate = useNavigate();
  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const people = patients.filter(p => `${p.name} ${p.id} ${p.condition}`.toLowerCase().includes(q)).slice(0, 3).map(p => ({ title: p.name, meta: `${p.id} · ${p.condition}`, to: "/patients", type: "Patient" }));
    const clinicians = doctors.filter(d => `${d.name} ${d.specialty}`.toLowerCase().includes(q)).slice(0, 3).map(d => ({ title: d.name, meta: d.specialty, to: "/resources", type: "Doctor" }));
    const documents = reports.filter(r => `${r.id} ${r.patient} ${r.department}`.toLowerCase().includes(q)).slice(0, 3).map(r => ({ title: r.id, meta: `${r.patient} · ${r.department}`, to: "/reports", type: "Report" }));
    return [...people, ...clinicians, ...documents].slice(0, 6);
  }, [query]);
  const closeMenus = () => { setProfile(false); setNotice(false); };
  useEffect(() => { const id = setInterval(() => setClock(new Date()), 1000); return () => clearInterval(id); }, []);
  return <header className="header">
    {(profile || notice) && <button className="menuDismiss" aria-label="Close open menu" onClick={closeMenus} />}
    <button className="iconBtn mobileOnly" onClick={menu}><Menu size={21} /></button>
    <div className="hospital"><span><Building2 size={17} /></span><div><strong>St. Joseph Medical Center</strong><small>Operations command center</small></div></div>
    <div className="searchWrap"><div className="search"><Search size={17} /><input aria-label="Search" value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => { if (e.key === "Escape") setQuery(""); if (e.key === "Enter" && searchResults[0]) { navigate(searchResults[0].to); setQuery(""); } }} placeholder="Search patients, doctors, reports…" /><kbd>⌘ K</kbd></div>
      {query && <div className="searchResults">{searchResults.length ? searchResults.map((result, index) => <button key={`${result.type}-${result.title}-${index}`} onClick={() => { navigate(result.to); setQuery(""); }}><span>{result.type}</span><div><b>{result.title}</b><small>{result.meta}</small></div><ArrowUpRight size={14} /></button>) : <p>No matching patients, doctors, or reports.</p>}</div>}
    </div>
    <div className="headerRight">
      <div className="liveClock"><span /><div>{clock.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}<small>Live</small></div></div>
      <button className="iconBtn" onClick={toggle} aria-label="Toggle theme">{theme === "light" ? <Moon size={19} /> : <Sun size={19} />}</button>
      <div className="popWrap"><button className="iconBtn" onClick={() => { setNotice(v => !v); setProfile(false); }} aria-label="Notifications"><Bell size={19} /><i className="notifyDot">3</i></button>
        {notice && <div className="popover notices"><h4>Notifications <span>3 new</span></h4><p><b className="redDot" />ICU capacity reached 82%<small>4 minutes ago</small></p><p><b className="amberDot" />Oxygen stock below target<small>18 minutes ago</small></p><p><b className="blueDot" />Forecast report is ready<small>1 hour ago</small></p></div>}
      </div>
      <div className="popWrap"><button className="profileBtn" onClick={() => { setProfile(v => !v); setNotice(false); }}><span className="avatar">SM</span><ChevronDown size={15} /></button>
        {profile && <div className="popover profilePop"><strong>Sarah Mitchell</strong><small>s.mitchell@stjoseph.org</small><hr /><button onClick={() => { closeMenus(); navigate("/settings"); }}>View profile</button><button onClick={() => { closeMenus(); navigate("/"); }}>Log out</button></div>}
      </div>
    </div>
  </header>;
}

function AppShell() {
  const [menu, setMenu] = useState(false);
  return <div className="appShell"><Sidebar open={menu} close={() => setMenu(false)} /><div className="mainShell"><Header menu={() => setMenu(true)} /><main><Routes>
    <Route path="/dashboard" element={<Dashboard />} />
    <Route path="/appointments" element={<Appointments />} />
    <Route path="/patients" element={<PatientPage />} />
    <Route path="/reports" element={<Reports />} />
    <Route path="/resources" element={<Resources />} />
    <Route path="/settings" element={<SettingsPage />} />
    <Route path="*" element={<Navigate to="/dashboard" replace />} />
  </Routes></main><QuickActions /><BottomNav /></div></div>;
}

function BottomNav() {
  const { pathname } = useLocation();
  return <nav className="bottomNav">{nav.slice(0, 5).map(({ label, to, icon: Icon }) =>
    <Link to={to} key={to} className={pathname === to ? "active" : ""}><Icon size={19} /><span>{label}</span></Link>
  )}</nav>;
}

function QuickActions() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();
  const actions = [
    { label: "Book appointment", icon: CalendarDays, to: "/appointments" },
    { label: "Add patient", icon: UserPlus, to: "/patients" },
    { label: "Generate report", icon: FilePlus2, to: "/reports" },
  ];
  return <div className={`quickActions ${open ? "open" : ""}`}>
    <AnimatePresence>{open && <motion.div className="quickMenu" initial={{ opacity: 0, y: 12, scale: .96 }} animate={{ opacity: 1, y: 0, scale: 1 }} exit={{ opacity: 0, y: 8, scale: .97 }}>{actions.map(({ label, icon: Icon, to }) => <button key={label} onClick={() => { navigate(to); setOpen(false); }}><span>{label}</span><i><Icon size={17} /></i></button>)}</motion.div>}</AnimatePresence>
    <button className="quickMain" aria-label={open ? "Close quick actions" : "Open quick actions"} onClick={() => setOpen(v => !v)}>{open ? <X size={21} /> : <Plus size={22} />}</button>
  </div>;
}

function PageTitle({ eyebrow, title, children }: { eyebrow?: string; title: string; children?: ReactNode }) {
  return <div className="pageTitle"><div>{eyebrow && <span className="eyebrow">{eyebrow}</span>}<h1>{title}</h1><p>Here’s what’s happening across your hospital today.</p></div>{children}</div>;
}

const kpis: { label: string; value: string; trend: number; note: string; icon: LucideIcon; color: string; data: number[] }[] = [
  { label: "Total patients", value: "2,847", trend: 8.2, note: "vs. last month", icon: Users, color: "blue", data: [31, 35, 34, 41, 39, 48, 53] },
  { label: "Today's appointments", value: "128", trend: 12.5, note: "18 remaining", icon: CalendarDays, color: "teal", data: [24, 30, 28, 36, 42, 41, 49] },
  { label: "Emergency cases", value: "14", trend: -4.1, note: "3 high priority", icon: Ambulance, color: "red", data: [39, 34, 36, 30, 28, 31, 26] },
  { label: "ICU beds available", value: "18", trend: 2.7, note: "of 64 total", icon: BedDouble, color: "violet", data: [21, 20, 18, 19, 17, 18, 18] },
  { label: "Revenue this month", value: "$438K", trend: 9.4, note: "78% of target", icon: WalletCards, color: "amber", data: [28, 34, 32, 38, 43, 46, 51] },
  { label: "Doctors on duty", value: "42", trend: 5.0, note: "7 departments", icon: Stethoscope, color: "cyan", data: [32, 35, 34, 37, 39, 40, 42] },
];

function KpiCard({ item, i }: { item: typeof kpis[number]; i: number }) {
  const Icon = item.icon; const spark = item.data.map((value, index) => ({ index, value }));
  return <motion.div className="kpi card" {...anim} transition={{ delay: i * .06, duration: .35 }}>
    <div className="kpiTop"><span className={`iconBox ${item.color}`}><Icon size={18} /></span><div className="spark"><ResponsiveContainer width="100%" height="100%"><LineChart data={spark}><Line dataKey="value" stroke={item.trend >= 0 ? "#14b8a6" : "#ef4444"} strokeWidth={2} dot={false} /></LineChart></ResponsiveContainer></div></div>
    <p>{item.label}</p><h3>{item.value}</h3><div className="trend">{item.trend >= 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}<b className={item.trend >= 0 ? "up" : "down"}>{Math.abs(item.trend)}%</b><span>{item.note}</span></div>
  </motion.div>;
}

function ChartCard({ title, subtitle, children, wide = false, badge }: { title: string; subtitle: string; children: ReactNode; wide?: boolean; badge?: string }) {
  return <motion.section className={`card chartCard ${wide ? "wide" : ""}`} {...anim}><div className="cardHead"><div><h2>{title}</h2><p>{subtitle}</p></div>{badge ? <span className="forecastBadge"><TrendingUp size={13} />{badge}</span> : <button className="dots"><MoreHorizontal /></button>}</div><div className="chartBody">{children}</div></motion.section>;
}
const axis = { stroke: "#94a3b8", fontSize: 11 };
const tooltip = { border: "none", borderRadius: 12, boxShadow: "0 8px 30px #0f172a18", fontSize: 12 };

function Dashboard() {
  const [loading, setLoading] = useState(true);
  useEffect(() => { const t = setTimeout(() => setLoading(false), 700); return () => clearTimeout(t); }, []);
  if (loading) return <Skeleton />;
  return <>
    <PageTitle eyebrow="Saturday, July 25" title="Good morning, Sarah"><div className="titleActions"><Link className="ghostBtn" to="/reports"><Download size={16} />Export</Link><Link className="primaryBtn" to="/appointments"><CalendarDays size={16} />New appointment</Link></div></PageTitle>
    <div className="kpiGrid">{kpis.map((item, i) => <KpiCard key={item.label} item={item} i={i} />)}</div>
    <section className="commandGrid">
      <ChartCard title="Patient visits" subtitle="Daily visits over the last 30 days" wide>
        <ResponsiveContainer width="100%" height="100%"><AreaChart data={visits}><defs><linearGradient id="visits" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#2563eb" stopOpacity=".28" /><stop offset="100%" stopColor="#2563eb" stopOpacity=".01" /></linearGradient></defs><CartesianGrid vertical={false} stroke="var(--grid)" /><XAxis dataKey="day" tick={axis} axisLine={false} tickLine={false} /><YAxis tick={axis} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltip} /><Area type="monotone" dataKey="actual" stroke="#2563eb" strokeWidth={2.4} fill="url(#visits)" /></AreaChart></ResponsiveContainer>
      </ChartCard>
      <LivePanel />
      <ChartCard title="Revenue overview" subtitle="Monthly revenue · $K">
        <ResponsiveContainer width="100%" height="100%"><BarChart data={revenue}><CartesianGrid vertical={false} stroke="var(--grid)" /><XAxis dataKey="month" tick={axis} axisLine={false} tickLine={false} /><YAxis tick={axis} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltip} /><Bar dataKey="value" fill="#2563eb" radius={[6, 6, 0, 0]} barSize={23} /></BarChart></ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Disease distribution" subtitle="Current inpatient diagnoses">
        <div className="donutWrap"><ResponsiveContainer width="55%" height="100%"><PieChart><Pie data={diseases} dataKey="value" innerRadius={55} outerRadius={78} paddingAngle={3}>{diseases.map(d => <Cell key={d.name} fill={d.color} />)}</Pie><Tooltip contentStyle={tooltip} /></PieChart></ResponsiveContainer><div className="legend">{diseases.map(d => <div key={d.name}><i style={{ background: d.color }} /><span>{d.name}</span><b>{d.value}%</b></div>)}</div><div className="donutTotal"><b>2,847</b><span>patients</span></div></div>
      </ChartCard>
      <ChartCard title="Bed occupancy" subtitle="Live capacity across departments">
        <div className="radialWrap"><ResponsiveContainer width="55%" height="100%"><RadialBarChart innerRadius="72%" outerRadius="100%" data={[{ value: 72, fill: "#2563eb" }]} startAngle={210} endAngle={-30}><RadialBar dataKey="value" cornerRadius={12} background={{ fill: "var(--grid)" }} /></RadialBarChart></ResponsiveContainer><div className="gaugeValue"><b>72%</b><span>occupied</span></div><div className="bedStats"><p><span>142</span> occupied</p><p><span>54</span> available</p></div></div>
      </ChartCard>
      <AppointmentsMini />
    </section>
    <ActivityFeed />
    <div className="sectionLabel"><div><span>Predictive intelligence</span><h2>Plan ahead with confidence</h2></div><span className="simBadge">SIMULATED FORECAST</span></div>
    <div className="forecastGrid">
      <ChartCard title="Predicted patient load" subtitle="Historical + next 4 days" badge="Forecast (Simulated Data)">
        <ResponsiveContainer width="100%" height="100%"><ComposedChart data={forecast}><CartesianGrid vertical={false} stroke="var(--grid)" /><XAxis dataKey="day" tick={axis} axisLine={false} tickLine={false} /><YAxis tick={axis} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltip} /><Area dataKey="high" stroke="none" fill="#93c5fd" fillOpacity=".16" /><Line type="monotone" dataKey="actual" stroke="#2563eb" strokeWidth={2.5} dot={{ r: 3 }} /><Line type="monotone" dataKey="forecast" stroke="#2563eb" strokeDasharray="6 5" strokeWidth={2.5} dot={{ r: 3 }} /></ComposedChart></ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Bed occupancy prediction" subtitle="Capacity forecast · next 7 days" badge="Forecast (Simulated Data)">
        <ResponsiveContainer width="100%" height="100%"><LineChart data={bedForecast}><CartesianGrid vertical={false} stroke="var(--grid)" /><XAxis dataKey="day" tick={axis} axisLine={false} tickLine={false} /><YAxis domain={[65, 95]} tick={axis} axisLine={false} tickLine={false} unit="%" /><Tooltip contentStyle={tooltip} /><Line dataKey="actual" stroke="#14b8a6" strokeWidth={2.5} dot={{ r: 3 }} /><Line dataKey="forecast" stroke="#14b8a6" strokeWidth={2.5} strokeDasharray="6 5" dot={{ r: 3 }} /></LineChart></ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Seasonal disease outlook" subtitle="Respiratory demand signal" badge="Forecast (Simulated Data)">
        <div className="insight"><span className="insightIcon"><TrendingUp /></span><div><small>Projected peak</small><b>+18.4%</b><p>Seasonal flu admissions expected to peak on July 31.</p></div></div><div className="miniBars">{[44,53,48,64,72,82,78,91,86,75].map((v,i)=><span key={i} style={{height:`${v}%`}} className={i>5?"future":""} />)}</div>
      </ChartCard>
    </div>
  </>;
}

function LivePanel() {
  const [live, setLive] = useState({ icu: 72, oxygen: 94.6, ambulances: 7 });
  useEffect(() => { const id = setInterval(() => setLive(v => ({ icu: Math.max(68, Math.min(84, v.icu + (Math.random() > .5 ? 1 : -1))), oxygen: +(Math.max(92, Math.min(97, v.oxygen + (Math.random() - .5) * .4)).toFixed(1)), ambulances: Math.max(5, Math.min(9, v.ambulances + (Math.random() > .7 ? 1 : Math.random() < .2 ? -1 : 0))) })), 2800); return () => clearInterval(id); }, []);
  return <motion.section className="card livePanel" {...anim}><div className="cardHead"><div><h2>Live monitoring</h2><p>Facility-wide vital metrics</p></div><span className="livePill"><i />LIVE</span></div>
    <div className="liveMetrics"><div><span className="metricIcon blue"><Gauge /></span><section><p>ICU occupancy<b>{live.icu}%</b></p><progress value={live.icu} max="100" /></section></div><div><span className="metricIcon teal"><Activity /></span><section><p>Average SpO₂<b>{live.oxygen}%</b></p><progress className="tealProg" value={live.oxygen} max="100" /></section></div><div><span className="metricIcon amber"><Ambulance /></span><section><p>Ambulances available<b>{live.ambulances}/12</b></p><progress className="amberProg" value={live.ambulances} max="12" /></section></div></div>
    <Link to="/resources" className="viewAll">Open resource command center <ArrowUpRight size={15} /></Link>
  </motion.section>;
}

function AppointmentsMini() {
  return <motion.section className="card appointmentsMini" {...anim}><div className="cardHead"><div><h2>Today’s schedule</h2><p>128 appointments · 18 remaining</p></div><Link to="/appointments">View all</Link></div><div className="appointmentList">{appointments.slice(0,4).map(a=><div key={a.id}><span className="avatar small">{a.avatar}</span><section><b>{a.patient}</b><small>{a.doctor} · {a.department}</small></section><time>{a.time}</time><span className={`status ${a.status.replace(" ","").toLowerCase()}`}>{a.status}</span></div>)}</div></motion.section>;
}

const activities = [
  { title: "Treatment plan updated", detail: "Dr. Arjun Mehta updated Michael Chen’s medication plan.", time: "4 min", icon: ClipboardCheck, color: "blue" },
  { title: "Emergency admission", detail: "Lucas Martin was assigned to Emergency Bay 04.", time: "12 min", icon: Ambulance, color: "red" },
  { title: "Diagnostic report completed", detail: "Chest X-ray report RPT-2044 is ready for review.", time: "28 min", icon: FileBarChart2, color: "violet" },
  { title: "ICU resource transfer", detail: "Two ventilators moved from Recovery to ICU.", time: "41 min", icon: BedDouble, color: "teal" },
];

function ActivityFeed() {
  const [expanded, setExpanded] = useState(false);
  const items = expanded ? activities : activities.slice(0, 3);
  return <motion.section className="card activityFeed" {...anim}><div className="cardHead"><div><h2>Recent activity</h2><p>Live clinical and operational updates</p></div><span className="livePill"><i />LIVE</span></div><div className="activityList">{items.map(({ title, detail, time, icon: Icon, color }) => <div key={title}><span className={`iconBox ${color}`}><Icon size={16} /></span><section><b>{title}</b><p>{detail}</p></section><time>{time} ago</time></div>)}</div><button className="viewAll activityToggle" onClick={() => setExpanded(v => !v)}>{expanded ? "Show less activity" : "View all activity"} <ArrowUpRight size={15} /></button></motion.section>;
}

function Skeleton() {
  return <div className="skeleton"><div className="sk skTitle" /><div className="skGrid">{[1,2,3,4,5,6].map(i=><div className="sk card" key={i} />)}</div><div className="sk skChart card" /></div>;
}

function Appointments() {
  const [view, setView] = useState<"Week"|"Month">("Week");
  const [weekOffset, setWeekOffset] = useState(0);
  const [booking, setBooking] = useState(false);
  const [scheduled, setScheduled] = useState<typeof appointments>(appointments);
  const [success, setSuccess] = useState("");
  const baseDate = view === "Month" ? new Date(2026, 6 + weekOffset, 1) : new Date(2026, 6, 20 + weekOffset * 7);
  const dayCount = view === "Month" ? 35 : 7;
  const calendarDays = Array.from({ length: dayCount }, (_, i) => {
    const date = new Date(baseDate);
    date.setDate(baseDate.getDate() + i);
    return date;
  });
  const first = calendarDays[0];
  const last = calendarDays[calendarDays.length - 1];
  const rangeLabel = view === "Month" ? first.toLocaleDateString("en-US", { month: "long", year: "numeric" }) : `${first.toLocaleDateString("en-US", { month: "short", day: "numeric" })} – ${last.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`;
  const colors: Record<string,string> = { Cardiology: "blueEvent", Pulmonology: "tealEvent", Neurology: "violetEvent", Emergency: "redEvent" };
  const submitBooking = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const values = new FormData(event.currentTarget);
    const patient = String(values.get("patient"));
    const doctor = String(values.get("doctor"));
    const date = String(values.get("date"));
    const time = String(values.get("time"));
    const selectedDoctor = doctors.find(d => d.name === doctor) ?? doctors[0];
    const selectedPatient = patients.find(p => p.name === patient) ?? patients[0];
    setScheduled(current => [...current, { id: `A${current.length + 1}`, patient, doctor, department: selectedDoctor.specialty, time, date, status: "Confirmed" as const, avatar: selectedPatient.name.split(" ").map(part => part[0]).join("").slice(0, 2) }]);
    setBooking(false);
    setSuccess(`Appointment booked for ${patient} on ${date} at ${time}.`);
    setTimeout(() => setSuccess(""), 3500);
  };
  return <>{success && <div className="successToast"><Check size={16}/>{success}</div>}<PageTitle eyebrow="Care delivery" title="Appointments"><div className="titleActions"><div className="segmented"><button className={view==="Week"?"active":""} onClick={()=>{setView("Week");setWeekOffset(0)}}>Week</button><button className={view==="Month"?"active":""} onClick={()=>{setView("Month");setWeekOffset(0)}}>Month</button></div><button className="primaryBtn" onClick={()=>setBooking(true)}><CalendarDays size={16}/>Book appointment</button></div></PageTitle>
    <div className="card calendarCard"><div className="calendarTop"><button aria-label="Previous period" onClick={()=>setWeekOffset(v=>v-1)}>‹</button><h2>{rangeLabel}</h2><button aria-label="Next period" onClick={()=>setWeekOffset(v=>v+1)}>›</button><button className="todayBtn" onClick={()=>setWeekOffset(0)}>Today</button></div>
      <div className={`calendarGrid ${view.toLowerCase()}`}>{calendarDays.map(date=>{const label=date.toLocaleDateString("en-US",{month:"short",day:"numeric"});const isToday=date.getDate()===25&&date.getMonth()===6;return <div className={isToday?"today":""} key={date.toISOString()}><header>{date.toLocaleDateString("en-US",{weekday:"short"})}<b>{date.getDate()}</b></header>{scheduled.filter(a=>a.date===label).map(a=><article key={a.id} className={colors[a.department]||"blueEvent"}><time>{a.time}</time><b>{a.patient}</b><small>{a.department}</small></article>)}</div>})}</div>
    </div>
    <div className="doctorStrip">{doctors.map(d=><div className="card doctorMini" key={d.id}><span className="avatar doctorAvatar">{d.initials}</span><div><b>{d.name}</b><small>{d.specialty}</small></div><span className={d.availability==="Available"?"available":"busy"}>{d.availability}</span></div>)}</div>
    <AnimatePresence>{booking&&<motion.div className="modalBackdrop" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onMouseDown={()=>setBooking(false)}><motion.form className="bookingModal card" onSubmit={submitBooking} initial={{opacity:0,y:20,scale:.97}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0,y:12,scale:.98}} onMouseDown={e=>e.stopPropagation()}><div className="cardHead"><div><span className="eyebrow">NEW APPOINTMENT</span><h2>Schedule patient visit</h2><p>Select a patient, clinician, date, and available time.</p></div><button type="button" className="iconBtn" onClick={()=>setBooking(false)}><X size={18}/></button></div><div className="bookingFields"><label>Patient<select name="patient" required>{patients.map(p=><option key={p.id}>{p.name}</option>)}</select></label><label>Doctor<select name="doctor" required>{doctors.map(d=><option key={d.id}>{d.name}</option>)}</select></label><label>Date<select name="date" required>{calendarDays.slice(0,view==="Month"?35:7).map(date=><option key={date.toISOString()}>{date.toLocaleDateString("en-US",{month:"short",day:"numeric"})}</option>)}</select></label><label>Time<select name="time" required>{["09:00","10:30","11:15","13:00","14:30","15:45"].map(time=><option key={time}>{time}</option>)}</select></label></div><div className="bookingActions"><button type="button" className="ghostBtn" onClick={()=>setBooking(false)}>Cancel</button><button type="submit" className="primaryBtn"><Check size={16}/>Confirm appointment</button></div></motion.form></motion.div>}</AnimatePresence>
  </>;
}

function PatientPage() {
  return <><PageTitle eyebrow="Patient care" title="Patient overview"><Link className="ghostBtn" to="/appointments"><Search size={16}/>View schedule</Link></PageTitle>
    <div className="patientHero card"><span className="avatar patientAvatar">MC</span><div><span className="eyebrow">INPATIENT · ROOM 418</span><h2>Michael Chen</h2><p>54 years · Male · O+ · Patient ID CS-1048</p></div><div className="riskBadge"><i/>Moderate risk</div><button className="ghostBtn"><MoreHorizontal/></button></div>
    <div className="patientGrid"><section className="card timelineCard"><div className="cardHead"><div><h2>Treatment timeline</h2><p>Admission to discharge journey</p></div><span className="status inprogress">In treatment</span></div><div className="timeline">{timeline.map((t,i)=><motion.div key={t.title} {...anim} transition={{delay:i*.06}} className={t.status}><span className="timeIcon">{t.status==="completed"?<Check/>:t.status==="current"?<Activity/>:<CircleDot/>}</span><div><b>{t.title}</b><p>{t.note}</p><small>{t.time}</small></div></motion.div>)}</div></section>
      <section className="card reportPaper"><div className="reportHeader"><Logo/><div><span>DIAGNOSTIC REPORT</span><b>RPT-2026-0723</b></div></div><hr/><div className="reportPatient"><div><small>PATIENT</small><b>Michael Chen</b><span>CS-1048 · 54/M</span></div><div><small>ATTENDING PHYSICIAN</small><b>Dr. Arjun Mehta</b><span>Pulmonology</span></div><div><small>REPORT DATE</small><b>July 23, 2026</b><span>12:35 PM</span></div></div><div className="diagnosisBox"><small>PRIMARY DIAGNOSIS</small><h3>Community-acquired pneumonia</h3><p>Right lower lobe consolidation, likely bacterial. CURB-65 score: 1 (low risk).</p></div><h3>Laboratory results</h3><table><tbody><tr><th>Test</th><th>Result</th><th>Reference</th><th>Flag</th></tr><tr><td>WBC</td><td>13.2 ×10⁹/L</td><td>4.5–11.0</td><td><span className="flag">HIGH</span></td></tr><tr><td>CRP</td><td>48 mg/L</td><td>&lt;10</td><td><span className="flag">HIGH</span></td></tr><tr><td>SpO₂</td><td>94%</td><td>95–100%</td><td><span className="flag amberFlag">LOW</span></td></tr><tr><td>Hemoglobin</td><td>14.1 g/dL</td><td>13.5–17.5</td><td><span className="normal">NORMAL</span></td></tr></tbody></table><h3>Physician notes</h3><p className="notes">Patient is responding well to IV ceftriaxone and azithromycin. Continue oxygen therapy at 2 L/min and repeat chest imaging in 48 hours.</p><div className="signature"><div><span>Arjun Mehta, MD</span><small>Electronically signed · Jul 23, 2026</small></div><button className="primaryBtn" onClick={() => window.print()}><Download size={15}/>Export PDF</button></div></section></div>
  </>;
}

function Reports() {
  const [dept,setDept]=useState("All"); const [doctor,setDoctor]=useState("All");
  const filtered=useMemo(()=>reports.filter(r=>(dept==="All"||r.department===dept)&&(doctor==="All"||r.doctor===doctor)),[dept,doctor]);
  const exportCsv=()=>{const rows=[["Report ID","Date","Patient","Department","Doctor","Encounters","Amount"],...filtered.map(r=>[r.id,r.date,r.patient,r.department,r.doctor,String(r.encounters),String(r.amount)])];const blob=new Blob([rows.map(r=>r.map(x=>`"${x}"`).join(",")).join("\n")],{type:"text/csv"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download="carescope-report.csv";a.click();URL.revokeObjectURL(url)};
  const total=filtered.reduce((s,r)=>s+r.amount,0);
  return <><PageTitle eyebrow="Analytics" title="Custom reports"><div className="titleActions"><button className="ghostBtn" onClick={() => window.print()}><FileBarChart2 size={16}/>Export PDF</button><button className="primaryBtn" onClick={exportCsv}><Download size={16}/>Export CSV</button></div></PageTitle>
    <section className="card filters"><div><label>Date range</label><select><option>July 1 – July 25, 2026</option><option>Last 30 days</option></select></div><div><label>Department</label><select value={dept} onChange={e=>setDept(e.target.value)}><option>All</option>{[...new Set(reports.map(r=>r.department))].map(x=><option key={x}>{x}</option>)}</select></div><div><label>Doctor</label><select value={doctor} onChange={e=>setDoctor(e.target.value)}><option>All</option>{doctors.map(d=><option key={d.id}>{d.name}</option>)}</select></div><button className="ghostBtn" onClick={() => { setDept("All"); setDoctor("All"); }}>Reset filters</button></section>
    <div className="reportSummary"><div className="card"><span className="iconBox blue"><ClipboardCheck/></span><p>Filtered encounters</p><h3>{filtered.reduce((s,r)=>s+r.encounters,0)}</h3></div><div className="card"><span className="iconBox teal"><WalletCards/></span><p>Net revenue</p><h3>${fmt.format(total)}</h3></div><div className="card"><span className="iconBox violet"><Stethoscope/></span><p>Care teams</p><h3>{new Set(filtered.map(r=>r.doctor)).size}</h3></div></div>
    <section className="card dataTable"><div className="cardHead"><div><h2>Clinical activity</h2><p>{filtered.length} matching records</p></div></div><div className="tableScroll"><table><thead><tr><th>Report</th><th>Date</th><th>Patient</th><th>Department</th><th>Physician</th><th>Encounters</th><th>Amount</th></tr></thead><tbody>{filtered.map(r=><tr key={r.id}><td><b>{r.id}</b></td><td>{r.date}</td><td>{r.patient}</td><td><span className="deptTag">{r.department}</span></td><td>{r.doctor}</td><td>{r.encounters}</td><td>${fmt.format(r.amount)}</td></tr>)}</tbody></table></div></section>
  </>;
}

const resources = [
  {name:"ICU beds",used:46,total:64,icon:BedDouble,color:"blue",unit:"beds"},
  {name:"Medical oxygen",used:7600,total:9200,icon:Activity,color:"teal",unit:"L"},
  {name:"Ventilators",used:31,total:44,icon:Gauge,color:"violet",unit:"units"},
  {name:"Blood bank",used:386,total:520,icon:Droplets,color:"red",unit:"packs"},
  {name:"Ambulances",used:5,total:12,icon:Ambulance,color:"amber",unit:"available"},
];
function Resources() {
  const [selected,setSelected]=useState("ICU");
  const nodes=[{name:"OPD",status:"healthy",x:"8%",y:"18%"},{name:"Radiology",status:"warning",x:"39%",y:"12%"},{name:"ICU",status:"critical",x:"67%",y:"18%"},{name:"Pharmacy",status:"healthy",x:"13%",y:"61%"},{name:"Emergency",status:"warning",x:"48%",y:"58%"}];
  return <><PageTitle eyebrow="Hospital operations" title="Resource command center"><span className="livePill"><i/>LIVE SYSTEM</span></PageTitle><div className="resourceGrid">{resources.map(r=>{const Icon=r.icon,pct=Math.round(r.used/r.total*100);return <div className="card resourceCard" key={r.name}><div><span className={`iconBox ${r.color}`}><Icon/></span><span className={pct>80?"criticalText":"okText"}>{pct>80?"Attention":"Optimal"}</span></div><h3>{r.name}</h3><p><b>{r.used.toLocaleString()}</b> / {r.total.toLocaleString()} {r.unit}</p><progress className={`${r.color}Prog`} value={r.used} max={r.total}/><small>{pct}% utilization</small></div>})}</div>
    <div className="twinGrid"><section className="card twin"><div className="cardHead"><div><span className="eyebrow">UNIQUE FEATURE</span><h2>Hospital digital twin</h2><p>Live spatial intelligence across your facility</p></div><span className="livePill"><i/>SYNCED</span></div><div className="floorMap"><div className="corridor h"/><div className="corridor v"/>{nodes.map(n=><button key={n.name} className={`node ${n.status} ${selected===n.name?"selected":""}`} style={{left:n.x,top:n.y}} onClick={()=>setSelected(n.name)}><span><Building2/></span><b>{n.name}</b><small>{n.status==="healthy"?"Operational":n.status==="warning"?"Elevated load":"Near capacity"}</small></button>)}<span className="floorLabel">LEVEL 01 · CLINICAL OPERATIONS</span></div></section>
      <section className="card twinDetail"><div className="cardHead"><div><span className="eyebrow">LIVE DEPARTMENT</span><h2>{selected}</h2><p>Updated just now</p></div><span className={`healthRing ${selected==="ICU"?"critical":""}`}><Activity/></span></div><div className="detailMetric"><p>Current load <b>{selected==="ICU"?"82%":"68%"}</b></p><progress value={selected==="ICU"?82:68} max="100"/></div><div className="twinStats"><div><small>Staff on duty</small><b>{selected==="ICU"?"14":"21"}</b><span>2 available</span></div><div><small>Active patients</small><b>{selected==="ICU"?"46":"73"}</b><span>+4 this hour</span></div></div><h3>Recent alerts</h3><div className="alertRow"><span className="amberDot"/><div><b>Capacity threshold approaching</b><small>12 minutes ago</small></div></div><div className="alertRow"><span className="blueDot"/><div><b>Shift handoff completed</b><small>38 minutes ago</small></div></div><Link className="primaryBtn full" to="/reports">View department analytics</Link></section></div>
    <div className="sectionLabel"><div><span>Clinical team</span><h2>Doctors on duty</h2></div></div><div className="doctorGrid">{doctors.map(d=><div className="card doctorCard" key={d.id}><div className="doctorTop"><span className="avatar doctorAvatar">{d.initials}</span><span className={d.availability==="Available"?"available":"busy"}>{d.availability}</span></div><h3>{d.name}</h3><p>{d.specialty}</p><div><span>★ {d.rating}</span><span>{d.patients} patients</span></div><Link className="ghostBtn full" to="/appointments">View schedule</Link></div>)}</div>
  </>;
}

function SettingsPage(){const {theme,accent,toggle,setAccent}=useTheme();const [saved,setSaved]=useState(false);const accents:{id:Accent;label:string;color:string}[]=[{id:"blue",label:"Clinical blue",color:"#2563eb"},{id:"emerald",label:"Care emerald",color:"#059669"},{id:"purple",label:"Insight purple",color:"#7c3aed"}];return <><PageTitle eyebrow="Workspace" title="Settings"/><section className="card settingsCard"><h2>Appearance</h2><p>Choose how CareScope looks during your session.</p><button className="settingRow" onClick={toggle}><span className="iconBox blue">{theme==="light"?<Sun/>:<Moon/>}</span><div><b>{theme==="light"?"Light mode":"Dark mode"}</b><small>Theme preference is kept in memory only</small></div><span className={`switch ${theme==="dark"?"on":""}`}><i/></span></button><div className="accentSection"><div className="accentTitle"><Palette size={16}/><div><b>Interface color</b><small>Apply a color preset across buttons, navigation, and highlights.</small></div></div><div className="accentOptions">{accents.map(item=><button key={item.id} className={accent===item.id?"active":""} onClick={()=>setAccent(item.id)}><i style={{background:item.color}}/>{item.label}{accent===item.id&&<Check size={14}/>}</button>)}</div></div><hr/><h2>Hospital profile</h2><div className="settingsFields"><label>Hospital name<input defaultValue="St. Joseph Medical Center"/></label><label>Timezone<input defaultValue="Asia / Calcutta"/></label><label>Department<input defaultValue="Clinical Operations"/></label></div><button className="primaryBtn" onClick={()=>{setSaved(true);setTimeout(()=>setSaved(false),2200)}}>{saved?<><Check size={16}/>Changes saved</>:"Save changes"}</button></section></>}

function Landing() {
  const navigate=useNavigate();
  return <div className="landing"><nav><Logo/><div><a href="#features">Capabilities</a><a href="#platform">Platform</a><button className="primaryBtn" onClick={()=>navigate("/dashboard")}>Launch dashboard <ArrowUpRight size={16}/></button></div></nav><main><motion.div className="heroCopy" initial={{opacity:0,y:24}} animate={{opacity:1,y:0}} transition={{duration:.55}}><span className="heroBadge"><i/>Healthcare intelligence, reimagined</span><h1>See the whole hospital.<br/><em>Act before it happens.</em></h1><p>CareScope turns complex clinical operations into clear, predictive intelligence—so every team can deliver better care, faster.</p><div><button className="primaryBtn heroBtn" onClick={()=>navigate("/dashboard")}>Explore live dashboard <ArrowUpRight/></button><span><b>99.98%</b> platform uptime</span></div></motion.div><motion.div className="heroVisual" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}} transition={{delay:.2,duration:.6}}><div className="previewTop"><Logo compact/><span>Operations overview</span><span className="livePill"><i/>LIVE</span></div><div className="previewKpis"><div><small>Patients today</small><b>2,847</b><span>↑ 8.2%</span></div><div><small>ICU capacity</small><b>72%</b><span>18 beds free</span></div><div><small>On-duty staff</small><b>126</b><span>7 departments</span></div></div><div className="previewChart"><div className="fakeChart">{[38,45,42,58,53,68,76,71,84,91].map((v,i)=><i key={i} style={{height:`${v}%`}}/>)}</div><div className="previewLive"><small>LIVE OPERATIONS</small><b>All systems monitored</b><p><span/>ICU occupancy <strong>72%</strong></p><p><span/>Oxygen supply <strong>94%</strong></p><p><span/>Ambulances <strong>7/12</strong></p></div></div></motion.div></main><section id="features" className="landingFeatures"><span className="eyebrow">ONE INTELLIGENT PLATFORM</span><h2>From signal to action, in one view.</h2><div>{[{icon:Activity,title:"Live operations",copy:"Monitor beds, staff, oxygen and ambulances as conditions change."},{icon:TrendingUp,title:"Predictive planning",copy:"Anticipate demand with clear simulated forecasts and confidence ranges."},{icon:Building2,title:"Digital twin",copy:"Navigate a living model of every department and resource."},{icon:ClipboardCheck,title:"Connected care",copy:"Follow each patient journey from admission to discharge."}].map(({icon:Icon,title,copy})=><article key={title}><span><Icon/></span><h3>{title}</h3><p>{copy}</p></article>)}</div></section><footer><Logo/><p>Clinical clarity for hospitals that never stand still.</p><span>© 2026 CareScope Analytics</span></footer></div>;
}

export default function App() {
  return <ThemeProvider><Routes><Route path="/" element={<Landing/>}/><Route path="/*" element={<AppShell/>}/></Routes></ThemeProvider>;
}
