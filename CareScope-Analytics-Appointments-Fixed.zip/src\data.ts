export type AppointmentStatus = "Confirmed" | "In progress" | "Completed" | "Pending";
export interface Appointment {
  id: string; patient: string; doctor: string; department: string; time: string;
  date: string; status: AppointmentStatus; avatar: string;
}
export interface Doctor {
  id: string; name: string; specialty: string; availability: string; rating: number; patients: number; initials: string;
}

export const patients = [
  { id: "CS-1048", name: "Michael Chen", age: 54, sex: "Male", blood: "O+", condition: "Community-acquired pneumonia", risk: "Moderate" },
  { id: "CS-1049", name: "Nadia Patel", age: 42, sex: "Female", blood: "A+", condition: "Seasonal influenza", risk: "Low" },
  { id: "CS-1050", name: "James Wilson", age: 68, sex: "Male", blood: "B-", condition: "Cardiac observation", risk: "High" },
  { id: "CS-1051", name: "Emma Thompson", age: 31, sex: "Female", blood: "AB+", condition: "Post-operative recovery", risk: "Low" },
  { id: "CS-1052", name: "Lucas Martin", age: 8, sex: "Male", blood: "O-", condition: "Respiratory infection", risk: "Moderate" },
  { id: "CS-1053", name: "Sophia Brown", age: 76, sex: "Female", blood: "A-", condition: "COPD exacerbation", risk: "High" },
];

export const doctors: Doctor[] = [
  { id: "D01", name: "Dr. Sarah Mitchell", specialty: "Cardiology", availability: "Available", rating: 4.9, patients: 8, initials: "SM" },
  { id: "D02", name: "Dr. Arjun Mehta", specialty: "Pulmonology", availability: "In surgery", rating: 4.8, patients: 11, initials: "AM" },
  { id: "D03", name: "Dr. Olivia Chen", specialty: "Neurology", availability: "Available", rating: 4.9, patients: 6, initials: "OC" },
  { id: "D04", name: "Dr. Marcus Reed", specialty: "Emergency", availability: "On call", rating: 4.7, patients: 14, initials: "MR" },
];

export const appointments: Appointment[] = [
  { id: "A01", patient: "Nadia Patel", doctor: "Dr. Arjun Mehta", department: "Pulmonology", time: "09:00", date: "Jul 20", status: "Completed", avatar: "NP" },
  { id: "A02", patient: "Michael Chen", doctor: "Dr. Arjun Mehta", department: "Pulmonology", time: "10:30", date: "Jul 21", status: "In progress", avatar: "MC" },
  { id: "A03", patient: "James Wilson", doctor: "Dr. Sarah Mitchell", department: "Cardiology", time: "11:15", date: "Jul 22", status: "Confirmed", avatar: "JW" },
  { id: "A04", patient: "Emma Thompson", doctor: "Dr. Olivia Chen", department: "Neurology", time: "13:00", date: "Jul 23", status: "Confirmed", avatar: "ET" },
  { id: "A05", patient: "Lucas Martin", doctor: "Dr. Marcus Reed", department: "Emergency", time: "14:30", date: "Jul 24", status: "Pending", avatar: "LM" },
  { id: "A06", patient: "Sophia Brown", doctor: "Dr. Sarah Mitchell", department: "Cardiology", time: "15:45", date: "Jul 25", status: "Confirmed", avatar: "SB" },
];

export const visits = [
  { day: "Jun 26", actual: 164 }, { day: "Jun 30", actual: 179 }, { day: "Jul 4", actual: 171 },
  { day: "Jul 8", actual: 196 }, { day: "Jul 12", actual: 204 }, { day: "Jul 16", actual: 193 },
  { day: "Jul 20", actual: 221 }, { day: "Jul 24", actual: 238 },
];
export const revenue = [
  { month: "Feb", value: 318 }, { month: "Mar", value: 346 }, { month: "Apr", value: 332 },
  { month: "May", value: 384 }, { month: "Jun", value: 412 }, { month: "Jul", value: 438 },
];
export const diseases = [
  { name: "Respiratory", value: 31, color: "#2563eb" }, { name: "Cardiac", value: 23, color: "#14b8a6" },
  { name: "Seasonal flu", value: 20, color: "#f59e0b" }, { name: "Orthopedic", value: 16, color: "#8b5cf6" },
  { name: "Other", value: 10, color: "#cbd5e1" },
];
export const forecast = [
  { day: "Mon", actual: 214 }, { day: "Tue", actual: 226 }, { day: "Wed", actual: 238 },
  { day: "Thu", forecast: 246, low: 232, high: 259 }, { day: "Fri", forecast: 263, low: 245, high: 280 },
  { day: "Sat", forecast: 231, low: 216, high: 247 }, { day: "Sun", forecast: 219, low: 202, high: 236 },
];
export const bedForecast = [
  { day: "Mon", actual: 76 }, { day: "Tue", actual: 78 }, { day: "Wed", actual: 81 },
  { day: "Thu", forecast: 83 }, { day: "Fri", forecast: 87 }, { day: "Sat", forecast: 84 }, { day: "Sun", forecast: 79 },
];
export const timeline = [
  { title: "Admission", note: "Admitted via Emergency · Room 418", time: "Jul 23 · 08:42", status: "completed" },
  { title: "Chest X-Ray", note: "Lower-lobe opacity identified", time: "Jul 23 · 09:25", status: "completed" },
  { title: "Blood Test", note: "CBC and metabolic panel completed", time: "Jul 23 · 10:10", status: "completed" },
  { title: "Diagnosis", note: "Community-acquired pneumonia", time: "Jul 23 · 12:35", status: "completed" },
  { title: "Treatment", note: "IV antibiotics and oxygen therapy", time: "Jul 23 · 13:20", status: "current" },
  { title: "Recovery", note: "Monitoring response to treatment", time: "Expected Jul 26", status: "pending" },
  { title: "Discharge", note: "Pending clinical clearance", time: "Expected Jul 28", status: "pending" },
];

export const reports = appointments.map((a, i) => ({
  id: `RPT-20${41 + i}`, date: `2026-07-${String(20 + i).padStart(2, "0")}`, patient: a.patient,
  department: a.department, doctor: a.doctor, encounters: 1 + (i % 3), amount: 420 + i * 185,
}));
